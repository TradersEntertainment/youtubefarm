
# main.py — MrBeast TikTok Bot with Turkish Subtitles & CAPTCHA bypass
# (içerik yukarıdaki assistant mesajında tanımlandı)
